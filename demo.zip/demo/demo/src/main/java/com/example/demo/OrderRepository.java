package com.example.demo;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface OrderRepository extends JpaRepository<Order, Integer> {

    public Order findOrderByOrderDis(String OrderDis);
    public Order findOrdersById(int id);
    public void deleteOrderById(int id);


}