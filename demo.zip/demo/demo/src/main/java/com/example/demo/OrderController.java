package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class OrderController {

    @Autowired
    private OrderService orderService;

    @GetMapping(value = "/utils/order", params = "order_description")
    public ResponseEntity<Order> getOrderByOrderDis(@RequestParam(name = "order_description") String orderDis) {
        return new ResponseEntity<>(orderService.getOrderByOrderDis(orderDis), HttpStatus.OK);
    }

    @GetMapping("/utils/order")
    public ResponseEntity<List<Order>> getAllOrder() {
        return new ResponseEntity<>(orderService.getAllOrder(), HttpStatus.OK);
    }

    @PostMapping("utils/order")
    public ResponseEntity<Order> createOrder(@RequestBody Order order) {
        return new ResponseEntity<>(orderService.createOrder(order), HttpStatus.OK);
    }

    @PutMapping("/utils/order/{id}")
    public ResponseEntity<Order> updateBank(@PathVariable int id, @RequestBody Order order) {
        return new ResponseEntity<Order>(orderService.updateOrder(id, order), HttpStatus.OK);
    }

    @DeleteMapping("utils/order/{id}")
    public ResponseEntity deleteOrder(@PathVariable int id) {
        orderService.deleteOrder(id);
        return new ResponseEntity(HttpStatus.OK);
    }
}
