package com.example.demo;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
@Transactional
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    public List<Order> getAllOrder() {
        return orderRepository.findAll();
    }


    public Order getOrderByOrderDis(String orderDis) {
        return OrderRepository.findOrderByOrderDis(orderDis);

    }

    public Order createOrder(Order order) {
        return orderRepository.save(order);
    }

    public Order updateOrder(int id, Order orderDetails) {
        Order order = orderRepository.findOrdersById(id);

        order.setOrderDis(orderDetails.getOrderDis());
        order.setOrderDate(orderDetails.getOrderDate());

        return orderRepository.save(order);
    }

    public void deleteOrder(int id) { orderRepository.deleteOrderById(id);
    }


}

