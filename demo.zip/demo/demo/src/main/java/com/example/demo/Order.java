package com.example.demo;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "ordertb")
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;

    @Column(name = "order_description", nullable = false, unique = true)
    private String orderDis;

    @Column(name = "order_date", nullable = false)
    private String orderDate;

    @Column(name = "created_at")
    @CreationTimestamp
    private Date createdAt;

    @Column(name = "updated_at")
    @UpdateTimestamp
    private Date updatedAt;

    public Order() {

    }

    public Order(String orderDis, String orderDate) {
        this.setOrderDis(orderDis);
        this.setOrderDate(orderDate);
    }

    public int getId() {
        return id;
    }

    public String getOrderDis() {
        return orderDis;
    }

    public void setOrderDis(String orderDis) {
        this.orderDis = orderDis;
    }

    public String getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(String orderDate) {
        this.orderDate = orderDate;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }
}
